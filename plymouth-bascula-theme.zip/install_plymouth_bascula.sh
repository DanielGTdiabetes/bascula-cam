#!/usr/bin/env bash
set -euo pipefail

echo "[1/6] Instalando plymouth y temas…"
sudo apt-get update
sudo apt-get install -y plymouth plymouth-themes

echo "[2/6] Copiando tema personalizado…"
sudo mkdir -p /usr/share/plymouth/themes/bascula
sudo cp bascula/* /usr/share/plymouth/themes/bascula/

echo "[3/6] Activando tema…"
sudo plymouth-set-default-theme bascula

echo "[4/6] Activando quiet splash en el kernel…"
# Actualizar /boot/firmware/cmdline.txt (línea única)
CMDLINE_FILE="/boot/firmware/cmdline.txt"
if [ ! -f "$CMDLINE_FILE" ]; then
  CMDLINE_FILE="/boot/cmdline.txt"
fi

# Añadir flags si no existen ya
add_flag() {
  local flag="$1"
  if ! grep -q "$flag" "$CMDLINE_FILE"; then
    sudo sed -i "1 s|$| $flag|" "$CMDLINE_FILE"
    echo "   + Añadido: $flag"
  else
    echo "   = Ya estaba: $flag"
  fi
}

add_flag "quiet"
add_flag "splash"
add_flag "plymouth.ignore-serial-consoles"
add_flag "vt.global_cursor_default=0"
add_flag "logo.nologo"
add_flag "loglevel=3"
# Mover consola para que plymouth use tty1
if grep -q "console=tty1" "$CMDLINE_FILE"; then
  sudo sed -i 's/console=tty1/console=tty3/g' "$CMDLINE_FILE"
  echo "   * Cambiado console=tty1 → console=tty3"
elif ! grep -q "console=tty3" "$CMDLINE_FILE"; then
  sudo sed -i "1 s|$| console=tty3|" "$CMDLINE_FILE"
  echo "   + Añadido console=tty3"
fi

echo "[5/6] Asegurar initramfs…"
# Generar/actualizar initramfs y declarar en config.txt
sudo update-initramfs -u
CONF_FILE="/boot/firmware/config.txt"
if [ ! -f "$CONF_FILE" ]; then
  CONF_FILE="/boot/config.txt"
fi
if ! grep -q "^initramfs initrd.img" "$CONF_FILE"; then
  echo "initramfs initrd.img followkernel" | sudo tee -a "$CONF_FILE" >/dev/null
  echo "   + Añadido 'initramfs initrd.img followkernel' a $(basename "$CONF_FILE")"
fi
# Ocultar splash arcoíris del firmware (opcional)
if ! grep -q "^disable_splash=" "$CONF_FILE"; then
  echo "disable_splash=1" | sudo tee -a "$CONF_FILE" >/dev/null
  echo "   + Añadido disable_splash=1"
fi

echo "[6/6] Regenerando initramfs para el tema…"
sudo plymouth-set-default-theme -R bascula

echo "Listo. Reinicia para probar el splash: sudo reboot"
