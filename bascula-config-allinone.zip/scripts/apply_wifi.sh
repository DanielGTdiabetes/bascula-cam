#!/usr/bin/env bash
# apply_wifi.sh — conecta a una red Wi‑Fi usando wpa_cli (para sistemas sin NetworkManager).
# Uso: sudo /home/pi/bascula-cam/scripts/apply_wifi.sh "SSID" "PSK"

set -euo pipefail

IFACE="${IFACE:-wlan0}"
SSID="${1:-}"
PSK="${2:-}"

log() { echo "[wifi] $*" >&2; }

if [[ -z "$SSID" || -z "$PSK" ]]; then
  log "Uso: $0 \"SSID\" \"PSK\""
  exit 2
fi

if ! command -v wpa_cli >/dev/null 2>&1; then
  log "wpa_cli no está instalado"
  exit 3
fi

if ! pgrep -x wpa_supplicant >/dev/null; then
  log "wpa_supplicant no está en ejecución"
  exit 4
fi

EXIST_ID="$(wpa_cli -i "$IFACE" list_networks | awk -F '\t' -v ssid="$SSID" '$2==ssid {print $1}' | head -n1 || true)"

if [[ -n "$EXIST_ID" ]]; then
  NET_ID="$EXIST_ID"
  log "Actualizando red existente id=$NET_ID ssid=\"$SSID\""
  wpa_cli -i "$IFACE" set_network "$NET_ID" psk "\"$PSK\"" >/dev/null
else
  NET_ID="$(wpa_cli -i "$IFACE" add_network | tr -d '\r' | tr -d '\n')"
  log "Añadida red id=$NET_ID ssid=\"$SSID\""
  wpa_cli -i "$IFACE" set_network "$NET_ID" ssid "\"$SSID\"" >/dev/null
  wpa_cli -i "$IFACE" set_network "$NET_ID" psk "\"$PSK\"" >/dev/null
fi

wpa_cli -i "$IFACE" set_network "$NET_ID" key_mgmt WPA-PSK >/dev/null || true
wpa_cli -i "$IFACE" enable_network "$NET_ID" >/dev/null
wpa_cli -i "$IFACE" select_network "$NET_ID" >/dev/null || true
wpa_cli -i "$IFACE" save_config >/dev/null
wpa_cli -i "$IFACE" reconfigure >/dev/null

sleep 3
if command -v dhclient >/dev/null 2>&1; then
  dhclient -v "$IFACE" || true
fi

log "Aplicado. Redes:"
wpa_cli -i "$IFACE" list_networks
