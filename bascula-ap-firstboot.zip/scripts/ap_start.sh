#!/usr/bin/env bash
set -euo pipefail

IFACE="${IFACE:-wlan0}"
AP_IP="10.42.0.1/24"

log(){ echo "[ap] $*" >&2; }

# Stop any DHCP client on wlan0 to avoid conflicts
if systemctl is-active --quiet dhcpcd; then
  log "Aviso: dhcpcd activo; se intentará continuar."
fi

# Bring interface up with static IP
ip link set "$IFACE" up || true
ip addr flush dev "$IFACE" || true
ip addr add "$AP_IP" dev "$IFACE"

# Enable IP forwarding (optional, no NAT by default)
sysctl -w net.ipv4.ip_forward=1 >/dev/null

# Start services
systemctl start dnsmasq.service || true
systemctl start hostapd.service

log "AP levantado en SSID 'Bascula-Setup' (clave: bascula1234). Conéctate y abre http://10.42.0.1:8080"
