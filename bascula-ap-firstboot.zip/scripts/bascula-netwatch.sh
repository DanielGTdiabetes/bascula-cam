#!/usr/bin/env bash
set -euo pipefail

IFACE="${IFACE:-wlan0}"
RETRY="${RETRY:-20}"   # seconds to wait for wifi at boot
log(){ echo "[netwatch] $*" >&2; }

# wait a bit for normal wifi to come up
for i in $(seq 1 "$RETRY"); do
  if ip route | grep -q "$IFACE"; then
    log "Wi‑Fi activo en $IFACE; no se arranca AP."
    systemctl stop bascula-ap.service || true
    exit 0
  fi
  sleep 1
done

# If still no route on wlan0, start AP
log "No hay Wi‑Fi en $IFACE tras ${RETRY}s → arrancando AP (Bascula-Setup)."
systemctl start bascula-ap.service || true
exit 0
