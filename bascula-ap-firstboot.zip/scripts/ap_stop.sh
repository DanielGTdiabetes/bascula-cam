#!/usr/bin/env bash
set -euo pipefail

IFACE="${IFACE:-wlan0}"
log(){ echo "[ap] $*" >&2; }

systemctl stop hostapd.service || true
systemctl stop dnsmasq.service || true

# Cleanup IP
ip addr flush dev "$IFACE" || true
log "AP detenido."
